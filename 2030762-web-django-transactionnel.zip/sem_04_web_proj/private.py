SECRET_KEY = 'django-insecure-%z6j*^h7(3b_nvc631x#u7a8$y%0ix!fm4zhrm)&bk+4fo*s+^'

# Admin :
# anvo
# M0t2Pas53